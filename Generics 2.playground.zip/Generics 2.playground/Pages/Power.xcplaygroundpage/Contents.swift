//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

//Make a function that takes in an integer and raises it to some exponent integer value and returns that as an integer

//2 ^ 2 = 4


func power(value: Int, exponent: Int) -> Int {
    var result = 1
    
    for _ in 0..<exponent {
        result *= value
    }
    
    return result
}

power(value: 2, exponent: 10)

//make this generic
//Generic constraint - limit the types that can be used in a generic type.
func power<Number: Numeric>(value: Number, exponent: Int) -> Number {
    var result: Number = 1
    
    for _ in 0..<exponent {
        result *= value
    }
    
    return result
}

power(value: 2.5, exponent: 10)

//Am I using single letters?
//Is there a better place to put this generic code?

extension Numeric {
    func power(exponent: Int) -> Self /*Numeric */ {
        var result: Self = 1
        
        for _ in 0..<exponent {
            result *= self
        }
        
        return result
    }
    
    
}

var x = 10

