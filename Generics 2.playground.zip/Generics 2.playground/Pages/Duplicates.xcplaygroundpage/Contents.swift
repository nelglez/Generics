//: [Previous](@previous)

import Foundation

let arr = [1, 2, 3, 4, 2, 3, 4, 2, 3, 2, 2, 9]

//: [Next](@next)
func removeDuplicates1(array: [Int]) -> [Int] {
    var uniqueValues: [Int] = []
    
    for value in array {
        if !uniqueValues.contains(value) {
            uniqueValues.append(value)
        }
    }
    return uniqueValues
}


func removeDuplicates2(array: [Int]) -> [Int] {
    return Array(Set(array))
}


//MARK: - Make the function work with any array elements

func removeDuplicates<Element: Equatable>(array: [Element]) -> [Element] {
    var uniqueValues: [Element] = []
    
    for value in array {
        if !uniqueValues.contains(value) {
            uniqueValues.append(value)
        }
    }
    return uniqueValues
}

removeDuplicates(array: arr)

//MARK: - Make the func work with any Sequence whose elements are any type. Return an array of the sequence's elements.

func removeDuplicates3<Seq: Sequence>(sequence: Seq) -> [Seq.Element] where Seq.Element: Equatable {
    var uniqueValues: [Seq.Element] = []
    
    for value in sequence {
        if !uniqueValues.contains(value) {
            uniqueValues.append(value)
        }
    }
    return uniqueValues
}

//Another way.

func removeDuplicates4<Seq>(sequence: Seq) -> [Seq.Element] where Seq: Sequence, Seq.Element: Equatable {
    var uniqueValues: [Seq.Element] = []
    
    for value in sequence {
        if !uniqueValues.contains(value) {
            uniqueValues.append(value)
        }
    }
    return uniqueValues
}

//Cleaner way.

extension Sequence where Element: Equatable {
    
    func removeDuplicates() -> [Element] {
        var uniqueValues: [Element] = []
        
        for value in self {
            if !uniqueValues.contains(value) {
                uniqueValues.append(value)
            }
        }
        return uniqueValues
    }
}

//Use case
arr.removeDuplicates()
