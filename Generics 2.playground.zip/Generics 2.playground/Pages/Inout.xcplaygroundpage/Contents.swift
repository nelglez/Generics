import UIKit

var x = 0

func incrementCount(of number: inout Int) {
    number += 1
}

incrementCount(of: &x)


print(x)
