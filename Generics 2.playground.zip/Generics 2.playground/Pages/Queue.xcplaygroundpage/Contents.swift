//: [Previous](@previous)

import Foundation

// First in, first out (FIFO)
struct Queue<Element> {
    
    init(elements: [Element]) {
        self.elements = elements
    }
    
    mutating func push(element: Element) {
        elements.append(element)
    }
    
    mutating func pop() -> Element? {
        guard !elements.isEmpty else { return nil }

        return elements.removeFirst()
        
//        let element = elements[0]
//        elements.remove(at: 0)
//        return element
    }
    
    // [1, 2, 3, 4]
    private var elements: [Element]
}

// Facade pattern - Hiding code that you don't want other people to access

var numberQueue = Queue(elements: [1, 2, 3, 4])

numberQueue.pop()
numberQueue.pop()
numberQueue.pop()
numberQueue.pop()
numberQueue.pop()
numberQueue.pop()


