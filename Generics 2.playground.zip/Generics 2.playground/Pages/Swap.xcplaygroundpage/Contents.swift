//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

// Challenge: Take in two Int parameters and swap their values.
// For example: if you have two variables x = 5 and y = 10. When run through the function, x's value should be 10 and y's value should be 5.

//func swap(x: inout Int, y: inout Int) {
//    let temp = x
//    x = y
//    y = temp
//}

func swap<Value>(x: inout Value, y: inout Value) {
    let temp = x
    x = y
    y = temp
}


var x = 5
var y = 10


swap(x: &x, y: &y)

print(x)
print(y)
